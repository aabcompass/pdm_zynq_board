/*
 * network_settings.h
 *
 *  Created on: Oct 20, 2016
 *      Author: alexander
 */

#ifndef SRC_NETWORK_SETTINGS_H_
#define SRC_NETWORK_SETTINGS_H_

#define FTP_SERVER_IP	0x0207A8C0

#endif /* SRC_NETWORK_SETTINGS_H_ */
