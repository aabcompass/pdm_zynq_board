/*
 * prototypes.h
 *
 *  Created on: 11 ���� 2016 �.
 *      Author: XILINX
 */

#ifndef PROTOTYPES_H_
#define PROTOTYPES_H_



#endif /* PROTOTYPES_H_ */
